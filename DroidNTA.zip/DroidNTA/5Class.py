import torch
import torch.nn as nn
import torch.utils.data as Data
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, recall_score, f1_score, precision_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
import time

# --- 1. 增强型残差模型架构 ---
class ResidualBlock(nn.Module):
    def __init__(self, in_dim, out_dim, dropout=0.2):
        super(ResidualBlock, self).__init__()
        self.fc = nn.Linear(in_dim, out_dim)
        self.bn = nn.BatchNorm1d(out_dim)
        self.relu = nn.LeakyReLU(0.2)
        self.dropout = nn.Dropout(dropout)
        
        self.shortcut = nn.Sequential()
        if in_dim != out_dim:
            self.shortcut = nn.Sequential(
                nn.Linear(in_dim, out_dim),
                nn.BatchNorm1d(out_dim)
            )

    def forward(self, x):
        residual = self.shortcut(x)
        out = self.fc(x)
        out = self.bn(out)
        out = self.relu(out)
        out = self.dropout(out)
        return out + residual 

class EnhancedNet(nn.Module):
    def __init__(self, input_dim=198, num_classes=5):
        super(EnhancedNet, self).__init__()
        self.layer1 = ResidualBlock(input_dim, 512)
        self.layer2 = ResidualBlock(512, 256)
        self.layer3 = ResidualBlock(256, 128)
        self.classifier = nn.Linear(128, num_classes)

    def forward(self, x):
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        return self.classifier(x)

# --- 2. 主程序 ---
if __name__ == '__main__':
    time_start = time.time()
    
    # 数据加载
    # data = pd.read_csv('AllFeature43class.csv', header=None).values 
    data = pd.read_csv('AllFeature5class.csv', header=None).values 
    
    # --- 核心回归：手动特征加权 ---
    apiF = data[:, 0:121] * 0.8    # API特征加权
    flowF = data[:, 121:198] * 0.2  # 流量特征加权
    X = np.concatenate((apiF, flowF), axis=1).astype(np.float32)
    raw_y = data[:, 198]
    
    # 标签处理（自动识别分类数并映射至0-N）
    le = LabelEncoder()
    y = le.fit_transform(raw_y)
    num_classes = len(le.classes_)
    
    # 划分数据集
    train_x, test_x, train_y, test_y = train_test_split(X, y, test_size=0.2, shuffle=True, random_state=2022)
    
    # 特征标准化（在手动加权后进行标准化，能进一步提升模型稳定性）
    scaler = StandardScaler()
    train_x = scaler.fit_transform(train_x)
    test_x = scaler.transform(test_x)
    
    # 数据集均衡处理 (WeightedRandomSampler)
    class_sample_count = np.array([len(np.where(train_y == t)[0]) for t in np.unique(train_y)])
    weight = 1. / class_sample_count
    samples_weight = torch.from_numpy(np.array([weight[t] for t in train_y])).double()
    sampler = Data.WeightedRandomSampler(samples_weight, len(samples_weight), replacement=True)
    
    # 数据封装
    train_dataset = Data.TensorDataset(torch.from_numpy(train_x).float(), torch.from_numpy(train_y).long())
    BATCH_SIZE = 128 
    train_loader = Data.DataLoader(dataset=train_dataset, batch_size=BATCH_SIZE, sampler=sampler)

    # 模型实例化
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = EnhancedNet(input_dim=198, num_classes=num_classes).to(device)
    
    # 损失函数与优化器
    criterion = nn.CrossEntropyLoss() 
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.001, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=8)

    # 训练循环
    EPOCHS = 100
    print(f"Starting training for {num_classes} classes on {device}...")
    for epoch in range(EPOCHS):
        model.train()
        epoch_losses = [] # 用于统计方差
        
        for batch_x, batch_y in train_loader:
            batch_x, batch_y = batch_x.to(device), batch_y.to(device)
            
            out = model(batch_x)
            loss = criterion(out, batch_y)
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            epoch_losses.append(loss.item())
        
        avg_loss = np.mean(epoch_losses)
        scheduler.step(avg_loss)
        
        # --- 每 10 个 Epoch 输出运行统计（包含均值、标准差、方差） ---
        if (epoch + 1) % 10 == 0:
            epoch_std = np.std(epoch_losses)
            epoch_var = np.var(epoch_losses)
            print(f"Epoch [{epoch+1}/{EPOCHS}]")
            print(f"  > Mean Loss: {avg_loss:.4f} | Std: {epoch_std:.6f} | Var: {epoch_var:.6f}")
            print(f"  > Current LR: {optimizer.param_groups[0]['lr']:.6f}")
            print("-" * 40)

    # 测试与评估
    time_test = time.time()
    model.eval()
    with torch.no_grad():
        test_inputs = torch.from_numpy(test_x).float().to(device)
        outputs = model(test_inputs)
        pred_y = torch.max(outputs, 1)[1].cpu().numpy()

    print("\n" + "="*40)
    print(f"Accuracy  : {accuracy_score(test_y, pred_y):.4f}")
    print(f"Recall    : {recall_score(test_y, pred_y, average='macro', zero_division=0):.4f}")
    print(f"Precision : {precision_score(test_y, pred_y, average='macro', zero_division=0):.4f}")
    print(f"F1-Score  : {f1_score(test_y, pred_y, average='macro', zero_division=0):.4f}")
    print("="*40)
    print(f"Total time cost: {time.time() - time_start:.2f} s")