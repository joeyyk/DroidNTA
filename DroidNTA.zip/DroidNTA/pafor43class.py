import torch.nn as nn
import torch
import torch.utils.data as Data
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,recall_score,f1_score,precision_score
import time
import matplotlib.pyplot as plt

# 网络类
class mynet(nn.Module):
    def __init__(self):
        super(mynet, self).__init__()
        self.fc = nn.Sequential(  # 添加神经元以及激活函数
            nn.Linear(198, 180),
            nn.Tanh(),
            nn.Linear(180, 120),
            nn.Tanh(),
            nn.Linear(120, 50)
        )
        self.mse = nn.CrossEntropyLoss()
        self.optim = torch.optim.Adam(params=self.parameters(), lr=0.0003)

    def forward(self, inputs):
        outputs = self.fc(inputs)
        return outputs

    def train(self, x, label):
        out = self.forward(x)  # 正向传播
        loss = self.mse(out, label)  # 根据正向传播计算损失print
        # print(loss,type(loss))
        self.optim.zero_grad()  # 梯度清零
        loss.backward()  # 计算梯度
        self.optim.step()  # 应用梯度更新参数

        return loss

    def test(self, test_):
        return self.fc(test_)


if __name__ == '__main__':
    time_start = time.time()
    data = pd.read_csv('AllFeature43Class.csv', header=None).values
    df = pd.DataFrame(data)
    loss = 0
    lossall = 0
    cur_los = []
    apiF = data[:, 0:121] * 0
    flowF = data[:, 121:198] * 1
    lab = data[:, 198:199]
    x = np.concatenate((apiF, flowF), axis=1)
    print('x data', x)
    y = data[:, -1]
    print('y result', y)
    train_x, test_x, train_y, test_y = train_test_split(x, y, test_size=0.2, shuffle=True, random_state=2022)
    mynet = mynet()
    train_dataset = Data.TensorDataset(torch.from_numpy(train_x).float(), torch.from_numpy(train_y).long())
    BATCH_SIZE = 5
    train_loader = Data.DataLoader(dataset=train_dataset, batch_size=BATCH_SIZE, shuffle=True, drop_last=True)
    i = 0
    for epoch in range(500):
        i = i + 1
        for step, (x, y) in enumerate(train_loader):
            y = torch.reshape(y, [BATCH_SIZE])
            loss = mynet.train(x, y).data.numpy()
            lossall = loss.astype(np.float32) + lossall

        if i % 100 == 0:
            print(i, 'epoch of loss', lossall)
        cur_los.append(lossall)
        lossall = 0
    time_test = time.time()
    out = mynet.test(torch.from_numpy(test_x).float())
    prediction = torch.max(out, 1)[1]  # 1返回index  0返回原值
    pred_y = prediction.data.numpy()
    test_y = test_y.reshape(1, -1)
    target_y = torch.from_numpy(test_y).long().data.numpy()[0]

    print("accuracy_score: %.4lf" % accuracy_score(target_y, pred_y))
    print("recall_score: %.4lf" % recall_score(target_y, pred_y, average='macro'))
    print("precision_score: %.4lf" % precision_score(target_y, pred_y, average='macro'))
    print("f1_score: %.4lf" % f1_score(target_y, pred_y, average='macro'))

    time_end = time.time()
    print("ALL time cost:", time_end - time_start, " s ")
    print("pre time cost:", (time_end - time_start) / 500, " s ")
    print("pre test time cost:", (time_end - time_test) / 500, " s ")

    # print(cur_los)
    # plt.plot(cur_los)
    # plt.title('loss curve')
    # plt.show()

