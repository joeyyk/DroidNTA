import torch
import torch.nn as nn
import torch.utils.data as Data
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, recall_score, f1_score, precision_score, roc_auc_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
import time

# --- 1. 增强型残差模型架构 ---
class ResidualBlock(nn.Module):
    def __init__(self, in_dim, out_dim, dropout=0.3):
        super(ResidualBlock, self).__init__()
        self.fc = nn.Linear(in_dim, out_dim)
        self.bn = nn.BatchNorm1d(out_dim)
        self.relu = nn.LeakyReLU(0.2)
        self.dropout = nn.Dropout(dropout)
        
        self.shortcut = nn.Sequential()
        if in_dim != out_dim:
            self.shortcut = nn.Sequential(
                nn.Linear(in_dim, out_dim),
                nn.BatchNorm1d(out_dim)
            )

    def forward(self, x):
        residual = self.shortcut(x)
        out = self.fc(x)
        out = self.bn(out)
        out = self.relu(out)
        out = self.dropout(out)
        return out + residual 

class EnhancedNet(nn.Module):
    def __init__(self, input_dim=198, num_classes=2):
        super(EnhancedNet, self).__init__()
        self.layer1 = ResidualBlock(input_dim, 512)
        self.layer2 = ResidualBlock(512, 256)
        self.layer3 = ResidualBlock(256, 128)
        self.classifier = nn.Sequential(
            nn.Linear(128, 64),
            nn.LeakyReLU(0.2),
            nn.Linear(64, num_classes)
        )

    def forward(self, x):
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        return self.classifier(x)

# --- 2. 主程序 ---
if __name__ == '__main__':
    time_start = time.time()
    
    # 加载数据（此处请替换为你实际的文件路径）
    data = pd.read_csv('AllFeature2class.csv', header=None).values 
    
    # --- 核心特征加权：0.8 API / 0.2 流量 ---
    apiF = data[:, 0:121] * 0.8
    flowF = data[:, 121:198] * 0.2
    X = np.concatenate((apiF, flowF), axis=1).astype(np.float32)
    raw_y = data[:, 198]
    
    # 标签编码
    le = LabelEncoder()
    y = le.fit_transform(raw_y)
    num_classes = len(le.classes_)
    
    # 数据集划分
    train_x, test_x, train_y, test_y = train_test_split(X, y, test_size=0.2, shuffle=True, random_state=2022)
    
    # 标准化
    scaler = StandardScaler()
    train_x = scaler.fit_transform(train_x)
    test_x = scaler.transform(test_x)
    
    # 均衡采样逻辑
    class_sample_count = np.array([len(np.where(train_y == t)[0]) for t in np.unique(train_y)])
    weight = 1. / class_sample_count
    samples_weight = torch.from_numpy(np.array([weight[t] for t in train_y])).double()
    sampler = Data.WeightedRandomSampler(samples_weight, len(samples_weight), replacement=True)
    
    train_dataset = Data.TensorDataset(torch.from_numpy(train_x).float(), torch.from_numpy(train_y).long())
    train_loader = Data.DataLoader(dataset=train_dataset, batch_size=128, sampler=sampler)

    # 修复 Python 3.7 兼容性，拆分赋值
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = EnhancedNet(input_dim=198, num_classes=num_classes).to(device)
    
    criterion = nn.CrossEntropyLoss() 
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.0005, weight_decay=1e-3)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=5)

    # 训练循环
    EPOCHS = 100
    print(f"Training started on {device} for {num_classes} classes...")
    
    for epoch in range(EPOCHS):
        model.train()
        epoch_losses = []
        
        for batch_x, batch_y in train_loader:
            batch_x, batch_y = batch_x.to(device), batch_y.to(device)
            out = model(batch_x)
            loss = criterion(out, batch_y)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            epoch_losses.append(loss.item())
        
        avg_loss = np.mean(epoch_losses)
        scheduler.step(avg_loss)
        
        # --- 针对性修改：每 10 个 Epoch 输出详尽统计信息 ---
        if (epoch + 1) % 10 == 0:
            e_std = np.std(epoch_losses)
            e_var = np.var(epoch_losses)
            # 增加变异系数 (CV)，这是衡量训练稳定性的进阶指标
            e_cv = e_std / avg_loss if avg_loss != 0 else 0
            
            print(f"Epoch [{epoch+1:03d}/{EPOCHS}]")
            print(f"  | Loss Mean: {avg_loss:.4f}")
            print(f"  | Loss Std : {e_std:.6f} (Variance: {e_var:.6f})")
            print(f"  | Stability (CV): {e_cv:.4f}") # CV 越小代表训练越稳
            print(f"  | Learning Rate : {optimizer.param_groups[0]['lr']:.6f}")
            print("-" * 45)

    # 评估阶段
    model.eval()
    with torch.no_grad():
        test_inputs = torch.from_numpy(test_x).float().to(device)
        outputs = model(test_inputs)
        probs = torch.softmax(outputs, dim=1).cpu().numpy()
        pred_y = torch.max(outputs, 1)[1].cpu().numpy()

    print("\n" + "="*45)
    print(f"Accuracy  : {accuracy_score(test_y, pred_y):.4f}")
    # 修复多分类报错，使用 average='macro'
    print(f"Recall    : {recall_score(test_y, pred_y, average='macro', zero_division=0):.4f}")
    print(f"Precision : {precision_score(test_y, pred_y, average='macro', zero_division=0):.4f}")
    print(f"F1-Score  : {f1_score(test_y, pred_y, average='macro', zero_division=0):.4f}")
    
    # 动态 AUC 计算
    if num_classes == 2:
        print(f"AUC Score : {roc_auc_score(test_y, probs[:, 1]):.4f}")
    else:
        print(f"AUC (OvR) : {roc_auc_score(test_y, probs, multi_class='ovr'):.4f}")
    print("="*45)
    print(f"Total time cost: {time.time() - time_start:.2f} s")