import pandas as pd
import os

def pdd(file):
    pdData = pd.read_csv(file)
    colmean = pd.DataFrame(pdData)
    return colmean

def fixName(filename):
    filename = filename.split('-')[-1].replace('.pcap_ISCX', '')
    return filename

def calFeature(fileIn, filenametxt, natualName):
    pdData = pd.read_csv(fileIn)
    colmean = pd.DataFrame(pdData)
    #for 43 calss
    # className = natualName.split('-')[1] + '_' + natualName.split('-')[2]
    #for 5 class
    className = natualName.split('-')[1]
    if className in dictLab:
        labnum = dictLab[className]
        newData = colmean.mean()[3:].to_frame().T
        newData.insert(0, 'filename', filenametxt)
        newData.insert(loc=len(newData.columns), column='label', value=labnum)  # 最后一列插入名称

    elif 'be' == natualName.split('-')[1]:
        newData = colmean.mean()[3:].to_frame().T
        newData.insert(0, 'filename', filenametxt)  # 第一列插入名称
        # newData.insert(loc=len(newData.columns), column='label', value='0')  # 最后一列插入名称
        newData.insert(loc=len(newData.columns), column='label', value='be')  # 最后一列插入名称

    return newData

def fileProcess(apkfile, outpath):
    df = pd.DataFrame()
    # apkfile = "./apk/"  # apk dir
    for filename in os.listdir(apkfile):
        if filename.endswith(".csv"):
            natualName = filename
            fixname = fixName(filename)
            filename = apkfile + filename
            filenametxt = fixname.replace('.csv', '') + '.txt'
            df2 = calFeature(filename, filenametxt, natualName)
            # break
            if df.empty:
                df = df2
            else:
                df = pd.concat([df, df2], axis=0)

    # 整体数据归一化处理
    columns = df.columns.tolist()
    for c in columns[1:-1]:
        d = df[c]
        MAX = d.max()
        MIN = d.min()
        if (MAX - MIN) != 0:
            df[c] = ((d - MIN) / (MAX - MIN)).tolist()
        else:
            continue

    print(df.isnull().values.any())
    df.fillna(0, inplace=True)
    print(df.isnull().values.any())
    print(df)
    df.to_csv(outpath, encoding='utf-8', index=False)

def concatfile(apifileIn,flowfileIn,outfile):
    apiData = pd.read_csv(apifileIn)
    flowData = pd.read_csv(flowfileIn)
    api = pd.DataFrame(apiData)
    flow = pd.DataFrame(flowData)
    x = api.values.tolist()
    y = flow.values.tolist()
    alllist = []
    columList = list(api.columns.values) + list(flow.columns.values)[1:]  # 列名
    alllist.append(columList)
    for i in x:
        for j in y:
            if j[0] in i:
                listData = i + j[1:]
                alllist.append(listData)

    tf = pd.DataFrame(data=alllist, index=None)
    print(tf)
    print(tf.shape)
    print(tf.isnull().values.any())
    tf.to_csv(outfile, encoding='utf-8', index=False, header=None)



if __name__ == '__main__':
    # 初始数据集 43 class
    # dictLab = {'BENIGN': 0, 'ad_ewind': 1, 'ad_feiwo': 2, 'ad_kemoge': 3, 'ad_mobidash': 4, 'ad_Chinese': 5, 'ad_dowgin': 6,
    #  'ad_selfmite': 7, 'ad_shuanet': 8, 'ad_gooligan': 9, 'ad_youmi': 10, 'sc_android.spy.277': 11,
    #  'sc_AvForAndroid': 12, 'sc_avpass': 13, 'sc_AndroidDefender': 14, 'sc_FakeApp.AL': 15, 'sc_fakeapp': 16,
    #  'sc_fakeav': 17, 'sc_fakejoboffer': 18, 'sc_FakeTaoBao': 19, 'sc_virusshield': 20, 'sc_penetho': 21,
    #  'sms_biige': 22, 'sms_fakenotify': 23, 'sms_plankton': 24, 'sms_smssniffer': 25, 'sms_fakeinst': 26,
    #  'sms_nandrobox': 27, 'ps_jifake': 28, 'ps_mazarbot': 29, 'ps_zsone': 30, 'ps_beanbot': 31, 'ra_jisut': 32,
    #  'ra_wannalocker': 33, 'ps_fakemart': 34, 'ra_koler': 35, 'ra_lockerpin': 36, 'ra_simplocker': 37, 'ra_svpeng': 38,
    #  'ra_charger': 39, 'ra_RansomBO': 40, 'ra_pletor': 41, 'ra_porndroid': 42}

    # 初始数据集 5 class
    # dictLab ={'BENIGN': 0, 'ad': 1, 'sc': 2, 'sms': 3, 'ps': 3, 'ra': 4}
    dictLab ={'BENIGN': 4, 'ad': 1, 'sc': 2, 'sms': 3, 'ps': 3, 'ra': 0}

    malAPK = "./malapk/"
    malpath = './concatFile/flowMalFeature.csv'

    benAPK = "./benapk/"
    benpath = './concatFile/flowBenFeature.csv'
    fileProcess(malAPK, malpath)
    print('-------------------------------- Malware FlowData Process Over --------------------------------')
    fileProcess(benAPK, benpath)
    print('-------------------------------- Bengin FlowData Process Over --------------------------------')

    apimalfileIn = "./concatFile/apiMalFeature.csv"
    flowmalfileIn = "./concatFile/flowMalFeature.csv"
    outmalfile = './concatFile/MalFeature.csv'
    concatfile(apimalfileIn, flowmalfileIn, outmalfile)
    print('-------------------------------- Malware ALl Feature Process Over --------------------------------')

    apibenfileIn = "./concatFile/apiBenFeature.csv"
    flowbenfileIn = "./concatFile/flowBenFeature.csv"
    outbenfile = './concatFile/BenFeature.csv'
    concatfile(apibenfileIn, flowbenfileIn, outbenfile)
    print('-------------------------------- Bengin ALl Feature Process Over --------------------------------')

    df = pd.DataFrame()
    Ben = './concatFile/BenFeature.csv'
    Mal = './concatFile/MalFeature.csv'
    BenData = pdd(Ben)
    MalData = pdd(Mal)
    AllData = pd.concat([BenData, MalData], axis=0)
    print(AllData.shape)
    print(AllData.isnull().values.any())
    AllData.to_csv('AllFeature4class.csv', encoding='utf-8', index=False)
    print('-------------------------------- ALl Feature Data Process Over --------------------------------')



