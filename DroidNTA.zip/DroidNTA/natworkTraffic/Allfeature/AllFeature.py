# import pandas as pd
#
# def pdd(file):
#     pdData = pd.read_csv(file)
#     colmean = pd.DataFrame(pdData)
#     return colmean
#
# df = pd.DataFrame()
# Adware = 'Adware.csv'
# Ran = 'Ransomware.csv'
# Sca = 'Scareware.csv'
# SMS = 'SMSmalware.csv'
# B2015 = 'B2015.csv'
# B2016 = 'B2016.csv'
# B2017 = 'B2017.csv'
#
# AdwData = pdd(Adware)
# RanData = pdd(Ran)
# ScaData = pdd(Sca)
# SMSData = pdd(SMS)
# B2015Data = pdd(B2015)
# B2016Data = pdd(B2016)
# B2017Data = pdd(B2017)
#
# AdwData = pd.concat([AdwData, RanData], axis=0)
# AdwData = pd.concat([AdwData, ScaData], axis=0)
# AdwData = pd.concat([AdwData, SMSData], axis=0)
# print(AdwData)
# print(AdwData.shape)
# AdwData.to_csv('MalFeature.csv', encoding='utf-8')
#
# B2015Data = pd.concat([B2015Data, B2016Data], axis=0)
# B2015Data = pd.concat([B2015Data, B2017Data], axis=0)
# print(B2015Data)
# print(B2015Data.shape)
# B2015Data.to_csv('BegFeature.csv', encoding='utf-8')
#
# B2015Data = pd.concat([B2015Data, AdwData], axis=0)
# B2015Data.to_csv('AllFeature.csv', encoding='utf-8')

import pandas as pd

def pdd(file):
    pdData = pd.read_csv(file)
    colmean = pd.DataFrame(pdData)
    return colmean

df = pd.DataFrame()
Ben = 'BenFeature.csv'
Mal = 'MalFeature.csv'
BenData = pdd(Ben)
MalData = pdd(Mal)
AllData = pd.concat([BenData, MalData], axis=0)
AllData.to_csv('AllFeature.csv', encoding='utf-8', index=False)
