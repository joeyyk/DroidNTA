import pandas as pd

if __name__ == '__main__':
    fileIn = "../concatFile/flowBenFeature.csv"
    pdData = pd.read_csv(fileIn)
    df = pd.DataFrame(pdData)
    columns = df.columns.tolist()
    for c in columns[2:-1]:
        d = df[c]
        MAX = d.max()
        MIN = d.min()
        if (MAX - MIN)!=0:
            df[c] = ((d - MIN) / (MAX - MIN)).tolist()
        else:
            continue
    df.fillna(0)
    print(df)
    print(df.isnull().values.any())
    df.to_csv('../concatFile/benFlowData.csv', encoding='utf-8')
