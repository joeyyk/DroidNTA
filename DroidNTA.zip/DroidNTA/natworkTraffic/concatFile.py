import pandas as pd

apifileIn = "./concatFile/apiBenFeature.csv"
flowfileIn = "./concatFile/flowBenFeature.csv"
apiData = pd.read_csv(apifileIn)
flowData = pd.read_csv(flowfileIn)
api = pd.DataFrame(apiData)
flow = pd.DataFrame(flowData)
x = api.values.tolist()
y = flow.values.tolist()
alllist = []
columList = list(api.columns.values) + list(flow.columns.values)[1:] #列名
alllist.append(columList)

for i in x:
    for j in y:
        if j[0] in i:
            listData = i + j[1:]
            alllist.append(listData)

tf = pd.DataFrame(data=alllist, index=None)
print(tf)
print(tf.shape)
print(tf.isnull().values.any())
tf.to_csv('./concatFile/BenFeature.csv', encoding='utf-8', index=False, header=None)





