import pandas as pd
import os


def fixName(filename):
    filename = filename.split('-')[-1].replace('.pcap_ISCX', '')
    return filename


def calFeature(fileIn, filenametxt):
    pdData = pd.read_csv(fileIn)
    colmean = pd.DataFrame(pdData)
    if 'BENIGN' == colmean.iloc[-1, -1]:
        print('Yes')
        newData = colmean.mean()[3:].to_frame().T
        newData.insert(0, 'filename', filenametxt) # 第一列插入名称
        newData.insert(loc=len(newData.columns), column='label', value='0')  # 最后一列插入名称
    else:
        print('No')
        newData = colmean.mean()[3:].to_frame().T
        newData.insert(0, 'filename', filenametxt)
        newData.insert(loc=len(newData.columns), column='label', value='1')  # 最后一列插入名称

    # print(newData)
    return newData
 
def fileProcess():
    df = pd.DataFrame()
    apkfile = "./apk/"  # apk dir
    for filename in os.listdir(apkfile):
        if filename.endswith(".csv"):
            fixname = fixName(filename)
            filename = apkfile + filename
            filenametxt = fixname.replace('.csv', '') + '.txt'
            df2 = calFeature(filename, filenametxt)
            # break
            if df.empty:
                df = df2
            else:
                df = pd.concat([df, df2], axis=0)

        # 保存到文件中
        # print(df)
        df.to_csv('./concatFile/flowBenFeature.csv', encoding='utf-8')


if __name__ == '__main__':
    fileProcess()

