#2class out


2 classes...
Epoch [010/100]
  | Loss Mean: 0.0009
  | Loss Std : 0.001217 (Variance: 0.000001)
  | Stability (CV): 1.2881
  | Learning Rate : 0.000500
---------------------------------------------
Epoch [020/100]
  | Loss Mean: 0.0003
  | Loss Std : 0.000475 (Variance: 0.000000)
  | Stability (CV): 1.4351
  | Learning Rate : 0.000500
---------------------------------------------
Epoch [030/100]
  | Loss Mean: 0.0001
  | Loss Std : 0.000095 (Variance: 0.000000)
  | Stability (CV): 0.9781
  | Learning Rate : 0.000500
---------------------------------------------
Epoch [040/100]
  | Loss Mean: 0.0001
  | Loss Std : 0.000045 (Variance: 0.000000)
  | Stability (CV): 0.8075
  | Learning Rate : 0.000500
---------------------------------------------
Epoch [050/100]
  | Loss Mean: 0.0000
  | Loss Std : 0.000028 (Variance: 0.000000)
  | Stability (CV): 0.8361
  | Learning Rate : 0.000250
---------------------------------------------
Epoch [060/100]
  | Loss Mean: 0.0000
  | Loss Std : 0.000022 (Variance: 0.000000)
  | Stability (CV): 0.7532
  | Learning Rate : 0.000250
---------------------------------------------
Epoch [070/100]
  | Loss Mean: 0.0320
  | Loss Std : 0.043124 (Variance: 0.001860)
  | Stability (CV): 1.3480
  | Learning Rate : 0.000250
---------------------------------------------
Epoch [080/100]
  | Loss Mean: 0.0008
  | Loss Std : 0.000982 (Variance: 0.000001)
  | Stability (CV): 1.2774
  | Learning Rate : 0.000063
---------------------------------------------
Epoch [090/100]
  | Loss Mean: 0.0016
  | Loss Std : 0.003742 (Variance: 0.000014)
  | Stability (CV): 2.3969
  | Learning Rate : 0.000016
---------------------------------------------
Epoch [100/100]
  | Loss Mean: 0.0012
  | Loss Std : 0.002341 (Variance: 0.000005)
  | Stability (CV): 2.0161
  | Learning Rate : 0.000008
---------------------------------------------

=============================================
Accuracy  : 0.9974
Recall    : 0.9983
Precision : 0.9946
F1-Score  : 0.9964
AUC Score : 1.0000
=============================================
Total time cost: 40.76 s


#5class output
5 classes 
Epoch [10/100]
  > Mean Loss: 0.0724 | Std: 0.063963 | Var: 0.004091
  > Current LR: 0.001000
----------------------------------------
Epoch [20/100]
  > Mean Loss: 0.0387 | Std: 0.020282 | Var: 0.000411
  > Current LR: 0.001000
----------------------------------------
Epoch [30/100]
  > Mean Loss: 0.1968 | Std: 0.196658 | Var: 0.038674
  > Current LR: 0.001000
----------------------------------------
Epoch [40/100]
  > Mean Loss: 0.0132 | Std: 0.005680 | Var: 0.000032
  > Current LR: 0.000500
----------------------------------------
Epoch [50/100]
  > Mean Loss: 0.0146 | Std: 0.017286 | Var: 0.000299
  > Current LR: 0.000250
----------------------------------------
Epoch [60/100]
  > Mean Loss: 0.0044 | Std: 0.002481 | Var: 0.000006
  > Current LR: 0.000250
----------------------------------------
Epoch [70/100]
  > Mean Loss: 0.0052 | Std: 0.006699 | Var: 0.000045
  > Current LR: 0.000125
----------------------------------------
Epoch [80/100]
  > Mean Loss: 0.0050 | Std: 0.008120 | Var: 0.000066
  > Current LR: 0.000125
----------------------------------------
Epoch [90/100]
  > Mean Loss: 0.0030 | Std: 0.003078 | Var: 0.000009
  > Current LR: 0.000125
----------------------------------------
Epoch [100/100]
  > Mean Loss: 0.0019 | Std: 0.001119 | Var: 0.000001
  > Current LR: 0.000125
----------------------------------------

========================================
Accuracy  : 0.9614
Recall    : 0.8698
Precision : 0.8747
F1-Score  : 0.8697
========================================
Total time cost: 39.82 s

#43output

 43 class
Training on cpu...
Epoch [10/100]
  > Loss Mean: 0.0678 | Std Dev: 0.025787 | Variance: 0.000665
  > Learning Rate: 0.001000
----------------------------------------
Epoch [20/100]
  > Loss Mean: 0.0209 | Std Dev: 0.006613 | Variance: 0.000044
  > Learning Rate: 0.001000
----------------------------------------
Epoch [30/100]
  > Loss Mean: 0.0211 | Std Dev: 0.007017 | Variance: 0.000049
  > Learning Rate: 0.001000
----------------------------------------
Epoch [40/100]
  > Loss Mean: 0.0220 | Std Dev: 0.013645 | Variance: 0.000186
  > Learning Rate: 0.001000
----------------------------------------
Epoch [50/100]
  > Loss Mean: 0.0054 | Std Dev: 0.001690 | Variance: 0.000003
  > Learning Rate: 0.001000
----------------------------------------
Epoch [60/100]
  > Loss Mean: 0.0179 | Std Dev: 0.042552 | Variance: 0.001811
  > Learning Rate: 0.001000
----------------------------------------
Epoch [70/100]
  > Loss Mean: 0.0041 | Std Dev: 0.002129 | Variance: 0.000005
  > Learning Rate: 0.000500
----------------------------------------
Epoch [80/100]
  > Loss Mean: 0.0023 | Std Dev: 0.000935 | Variance: 0.000001
  > Learning Rate: 0.000500
----------------------------------------
Epoch [90/100]
  > Loss Mean: 0.0034 | Std Dev: 0.003317 | Variance: 0.000011
  > Learning Rate: 0.000500
----------------------------------------
Epoch [100/100]
  > Loss Mean: 0.0016 | Std Dev: 0.001044 | Variance: 0.000001
  > Learning Rate: 0.000250
----------------------------------------

=============================================
Final Results for 43-Class Detection:
Accuracy  : 0.9254
Recall    : 0.6528
Precision : 0.6315
F1-Score  : 0.6097
=============================================
Total time cost: 40.56 s