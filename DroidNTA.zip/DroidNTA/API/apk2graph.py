# coding:utf-8
'''
info:通过使用androguard把目标为apkpath的APK转换为API调用图存储在路径为gmlpath的gml文件中
'''
import os
import importlib,sys
importlib.reload(sys)

def extractcg(apkpath,gmlpath):
    cmd="androguard cg {} -o {}".format(apkpath, gmlpath)
    os.system(cmd)
    print('success')


if __name__ == '__main__':
    apkpath = "E://DataForTest//data//1.apk"
    gmlpath = "E://DataForTest//gml//1.gml"
    extractcg(apkpath, gmlpath)