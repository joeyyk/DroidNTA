import torch
import torch.nn as nn
import torch.utils.data as Data
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, recall_score, f1_score, precision_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
import time

# --- 1. 增强型残差模型架构 ---
class ResidualBlock(nn.Module):
    def __init__(self, in_dim, out_dim, dropout=0.2):
        super(ResidualBlock, self).__init__()
        self.fc = nn.Linear(in_dim, out_dim)
        self.bn = nn.BatchNorm1d(out_dim)
        self.relu = nn.LeakyReLU(0.2)
        self.dropout = nn.Dropout(dropout)
        
        # 维度对齐：如果输入输出维度不同，使用线性映射同步
        self.shortcut = nn.Sequential()
        if in_dim != out_dim:
            self.shortcut = nn.Sequential(
                nn.Linear(in_dim, out_dim),
                nn.BatchNorm1d(out_dim)
            )

    def forward(self, x):
        residual = self.shortcut(x)
        out = self.fc(x)
        out = self.bn(out)
        out = self.relu(out)
        out = self.dropout(out)
        return out + residual 

class EnhancedNet(nn.Module):
    def __init__(self, input_dim=198, num_classes=43):
        super(EnhancedNet, self).__init__()
        # 针对43分类增加模型宽度
        self.layer1 = ResidualBlock(input_dim, 512)
        self.layer2 = ResidualBlock(512, 256)
        self.layer3 = ResidualBlock(256, 128)
        self.classifier = nn.Linear(128, num_classes)

    def forward(self, x):
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        return self.classifier(x)

# --- 2. 主程序 ---
if __name__ == '__main__':
    time_start = time.time()
    
    # 数据加载：请确保文件名为你的43分类数据集
    data = pd.read_csv('AllFeature43class.csv', header=None).values 
    # data = pd.read_csv('AllFeature5class.csv', header=None).values # 示例文件名
    
    # --- 核心逻辑：手动特征加权 (0.8 API / 0.2 Flow) ---
    apiF = data[:, 0:121] * 0.8
    flowF = data[:, 121:198] * 0.2
    X = np.concatenate((apiF, flowF), axis=1).astype(np.float32)
    raw_y = data[:, 198]
    
    # 标签处理：强制映射至 0-42 范围
    le = LabelEncoder()
    y = le.fit_transform(raw_y)
    num_classes = len(le.classes_)
    print(f"Total classes detected: {num_classes}")
    
    # 划分数据集
    train_x, test_x, train_y, test_y = train_test_split(X, y, test_size=0.2, shuffle=True, random_state=2022)
    
    # 特征标准化
    scaler = StandardScaler()
    train_x = scaler.fit_transform(train_x)
    test_x = scaler.transform(test_x)
    
    # 数据集均衡处理 (WeightedRandomSampler)
    class_sample_count = np.array([len(np.where(train_y == t)[0]) for t in np.unique(train_y)])
    weight = 1. / class_sample_count
    samples_weight = torch.from_numpy(np.array([weight[t] for t in train_y])).double()
    sampler = Data.WeightedRandomSampler(samples_weight, len(samples_weight), replacement=True)
    
    # 数据封装
    train_dataset = Data.TensorDataset(torch.from_numpy(train_x).float(), torch.from_numpy(train_y).long())
    BATCH_SIZE = 128 # 43分类建议使用较大的 Batch 以覆盖更多类别
    train_loader = Data.DataLoader(dataset=train_dataset, batch_size=BATCH_SIZE, sampler=sampler)

    # 模型实例化
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = EnhancedNet(input_dim=198, num_classes=num_classes).to(device)
    
    # 损失函数与优化器
    criterion = nn.CrossEntropyLoss() 
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.001, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=8)

    # 训练循环
    EPOCHS = 100
    print(f"Training on {device}...")
    
    for epoch in range(EPOCHS):
        model.train()
        epoch_losses = [] # 用于统计方差和标准差
        
        for batch_x, batch_y in train_loader:
            batch_x, batch_y = batch_x.to(device), batch_y.to(device)
            
            out = model(batch_x)
            loss = criterion(out, batch_y)
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            epoch_losses.append(loss.item())
        
        avg_loss = np.mean(epoch_losses)
        scheduler.step(avg_loss)
        
        # --- 每 10 个 Epoch 输出运行方差/标准差 ---
        if (epoch + 1) % 10 == 0:
            epoch_std = np.std(epoch_losses)
            epoch_var = np.var(epoch_losses)
            print(f"Epoch [{epoch+1}/{EPOCHS}]")
            print(f"  > Loss Mean: {avg_loss:.4f} | Std Dev: {epoch_std:.6f} | Variance: {epoch_var:.6f}")
            print(f"  > Learning Rate: {optimizer.param_groups[0]['lr']:.6f}")
            print("-" * 40)

    # 测试与评估
    model.eval()
    with torch.no_grad():
        test_inputs = torch.from_numpy(test_x).float().to(device)
        outputs = model(test_inputs)
        pred_y = torch.max(outputs, 1)[1].cpu().numpy()

    print("\n" + "="*45)
    print(f"Final Results for {num_classes}-Class Detection:")
    print(f"Accuracy  : {accuracy_score(test_y, pred_y):.4f}")
    # 43分类必须看 Macro 后的指标，确保少数类没被忽略
    print(f"Recall    : {recall_score(test_y, pred_y, average='macro', zero_division=0):.4f}")
    print(f"Precision : {precision_score(test_y, pred_y, average='macro', zero_division=0):.4f}")
    print(f"F1-Score  : {f1_score(test_y, pred_y, average='macro', zero_division=0):.4f}")
    print("="*45)
    print(f"Total time cost: {time.time() - time_start:.2f} s")